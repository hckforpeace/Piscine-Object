#include "Bank.hpp"
#include <exception>
#include <iostream>

int main() {
  Bank b;
  b.createAccount(452);
  b.createAccount(4000);
  b.createAccount(123);
  b.createAccount(444);
  b.createAccount(100);
  b.createAccount(0);

  try {
    b.createAccount(-1);
  } catch (const std::exception &e) {
    std::cout << e.what() << std::endl;
  }

  std::cout << "dsiplaying with operator [] " << b[0] << std::endl;

  b.displayAccounts();

  b.depositAccount(0, 400.0);
  std::cout << "dsiplaying with operator [] " << b[0] << std::endl;

  // Throws Error
  // try {
  //   b.applyLoan(10000, 0);
  // } catch (const std::exception &e) {
  //   std::cout << e.what() << std::endl;
  // }

  // Throws Error
  try {
    b.deleteAccount(45);
  } catch (const std::exception &e) {
    std::cout << e.what() << std::endl;
  }

  b.deleteAccount(0);
  b.deleteAccount(1);
  b.deleteAccount(2);
  b.deleteAccount(3);
  b.deleteAccount(4);
  b.deleteAccount(5);
  //
  // b.displayAccounts();
  std::cout << b;
  return (0);
}

// errors
// int main() {
//
//   Bank b;
//   b.createAccount(452);
//   b.createAccount(4000);
//
//   Bank::Account *a;
//
//   a = b[0];
// }
